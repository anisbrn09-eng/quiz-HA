Quiz SAQQARAH — Examen (mode sans minuterie, pass direct)
- 30 questions issues de la vidéo, 20 tirées au hasard par session.
- Comportement: au clic sur une réponse, l'utilisateur passe directement à la question suivante.
- Ouvrir index.html dans un navigateur moderne pour l'utiliser.
